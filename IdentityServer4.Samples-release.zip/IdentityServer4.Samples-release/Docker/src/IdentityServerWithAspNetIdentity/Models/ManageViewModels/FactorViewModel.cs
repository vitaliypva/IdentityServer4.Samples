﻿namespace IdentityServerWithAspNetIdentity.Models.ManageViewModels
{
    public class FactorViewModel
    {
        public string Purpose { get; set; }
    }
}
