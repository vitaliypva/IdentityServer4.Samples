# Quickstart #4: Adding external Authentication

This quickstart adds support for Google authentication.
