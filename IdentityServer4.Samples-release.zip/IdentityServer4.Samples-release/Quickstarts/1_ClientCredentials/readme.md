# Quickstart #1: Securing an API using Client Credentials

The first quickstart sets up a minimal identityserver that shows how to protect an API using the OAuth 2.0 client credentials grant.
This approach is typically used for server to server communication.
